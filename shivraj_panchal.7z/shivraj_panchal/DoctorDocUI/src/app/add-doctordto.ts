export class AddDoctordto {

    id:any;
    username:any;
    password:any;


}
