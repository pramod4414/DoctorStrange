import { Component, OnInit } from '@angular/core';
import { AddDoctordto } from '../add-doctordto';
import { LoginpartService } from '../AllServices/loginpart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-doctor',
  templateUrl: './add-doctor.component.html',
  styleUrls: ['./add-doctor.component.css']
})
export class AddDoctorComponent implements OnInit {

  doctor = new AddDoctordto();

  constructor(private _service : LoginpartService, private _route:Router ) { }

  ngOnInit(): void {
  }


  addDoctorToRemote(){

console.log(this.doctor);



this._service.addEmployeeToRemote(this.doctor).subscribe(data => {
  this._route.navigate(['/AdminDoctorOperation']);
},
  error => console.log("error")
)


  }


  previous(){


  }
}
