import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HeaderComponent } from './commancomp/header/header.component';
import { FooterComponent } from './commancomp/footer/footer.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { HomeComponent } from './home/home.component';
import { DoctorInfoComponent } from './doctor-info/doctor-info.component';
import { AdminDoctorListOperationComponent } from './admin-doctor-list-operation/admin-doctor-list-operation.component';
import { UpdateDoctorLoginDetailComponent } from './update-doctor-login-detail/update-doctor-login-detail.component';
import { AddDoctorComponent } from './add-doctor/add-doctor.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HeaderComponent,
    FooterComponent,
    AdminLoginComponent,
    HomeComponent,
    DoctorInfoComponent,
    AdminDoctorListOperationComponent,
    UpdateDoctorLoginDetailComponent,
    AddDoctorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
