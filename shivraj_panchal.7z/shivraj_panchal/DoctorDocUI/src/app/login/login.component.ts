import { Component, OnInit } from '@angular/core';
import { Login } from '../login';
import { Router } from '@angular/router';
import { LoginpartService } from '../AllServices/loginpart.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})


export class LoginComponent implements OnInit {

  login = new Login();



  constructor(private _route: Router,
    private _loginService: LoginpartService) {


  }


  loginDataFromRemote: any[] = [];

  ngOnInit(): void {


    this._loginService.checkUserValid()
      .subscribe(data => {
        console.log("the data from backend" + JSON.stringify(data));

        this.loginDataFromRemote = data;

      });

  }



  checkCredientials() {

    console.log("function called checkCredientials" + this.login.username + "*****pass" + this.login.password);
    

     
    for(let a=0;a<this.loginDataFromRemote.length;a++){
  
        if (this.loginDataFromRemote[a].username == this.login.username && this.loginDataFromRemote[a].password == this.login.password) {
             this._route.navigate(['/doctorinfo']);

           }
  
      }

  }









}
