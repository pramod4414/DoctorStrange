import { AdminDoctor } from './admin-doctor';

describe('AdminDoctor', () => {
  it('should create an instance', () => {
    expect(new AdminDoctor()).toBeTruthy();
  });
});
