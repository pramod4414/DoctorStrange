import { Component, OnInit } from '@angular/core';
import { AdminDoctor } from '../admin-doctor';
import { LoginpartService } from '../AllServices/loginpart.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update-doctor-login-detail',
  templateUrl: './update-doctor-login-detail.component.html',
  styleUrls: ['./update-doctor-login-detail.component.css']
})
export class UpdateDoctorLoginDetailComponent implements OnInit {
  doctor = new AdminDoctor();

  constructor(private _service: LoginpartService, private _route: Router, private _activateroute: ActivatedRoute) { }

  ngOnInit(): void {

  //  let id = parseInt(this._activateroute.snapshot.paramMap.get('id'));

  let id=2;

    this._service.fetchEmployeeByIdRemote(id).subscribe(data => {
      console.log(data);
      this.doctor=data;

    }, error => console.log("error")
    )


  }

  updateDoctor(){

    this._service.addEmployeeToRemote(this.doctor).subscribe(data => {
      this._route.navigate(['/AdminDoctorOperation']);
    },
      error => console.log("error")
    )



  }


  previous(){


  }


}
