import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateDoctorLoginDetailComponent } from './update-doctor-login-detail.component';

describe('UpdateDoctorLoginDetailComponent', () => {
  let component: UpdateDoctorLoginDetailComponent;
  let fixture: ComponentFixture<UpdateDoctorLoginDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateDoctorLoginDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateDoctorLoginDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
