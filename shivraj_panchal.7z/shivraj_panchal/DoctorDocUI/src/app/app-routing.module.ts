import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { DoctorInfoComponent } from './doctor-info/doctor-info.component';
import { AdminDoctorListOperationComponent } from './admin-doctor-list-operation/admin-doctor-list-operation.component';
import { UpdateDoctorLoginDetailComponent } from './update-doctor-login-detail/update-doctor-login-detail.component';
import { AddDoctorComponent } from './add-doctor/add-doctor.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
 
  { path: 'DoctorComponent', component: LoginComponent },
  { path: 'AdminComponent', component: AdminLoginComponent },
  {path:'doctorinfo',component:DoctorInfoComponent},
  {path:'AdminDoctorOperation',component:AdminDoctorListOperationComponent},
  {path:'updateLoginDetailDoctor',component:UpdateDoctorLoginDetailComponent},
  {path:'addDoctor',component:AddDoctorComponent}

  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
