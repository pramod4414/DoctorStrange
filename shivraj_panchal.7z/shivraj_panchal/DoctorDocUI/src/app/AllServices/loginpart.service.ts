import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { AdminDoctor } from '../admin-doctor';

@Injectable({
  providedIn: 'root'
})
export class LoginpartService {

  constructor(private _http:HttpClient) { }



checkUserValid():Observable<any>{
  return this._http.get<any>("http://localhost:5828//getAllLoginData");
}




checkAdminValid():Observable<any>{
  return this._http.get<any>("http://localhost:5828//getAdminData");
}



deleteDoctorByIdRemote(id:number):Observable<any>{
  return this._http.delete<any>("http://localhost:5828//deleteEmployee/"+id);
}


addEmployeeToRemote(employee:AdminDoctor):Observable<any>{
  return this._http.post<any>("http://localhost:5828/addemployee",employee);
}

// addDoctorToRemote(doctor:Employee):Observable<any>{
//   return this._http.post<any>("http://localhost:5555/updateDoctor",doctor);
// }


fetchEmployeeByIdRemote(id:number):Observable<any>{
  return this._http.get<any>("http://localhost:5828//searchEmployee/"+id);
}


}
