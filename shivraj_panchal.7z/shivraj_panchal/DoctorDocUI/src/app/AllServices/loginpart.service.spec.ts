import { TestBed } from '@angular/core/testing';

import { LoginpartService } from './loginpart.service';

describe('LoginpartService', () => {
  let service: LoginpartService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LoginpartService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
