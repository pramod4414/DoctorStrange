export class Admincheck {

    username: string
    password: string
}
