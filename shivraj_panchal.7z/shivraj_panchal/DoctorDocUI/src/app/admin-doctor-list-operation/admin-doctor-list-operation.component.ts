import { Component, OnInit } from '@angular/core';
import { AdminDoctor } from '../admin-doctor';
import { LoginpartService } from '../AllServices/loginpart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-doctor-list-operation',
  templateUrl: './admin-doctor-list-operation.component.html',
  styleUrls: ['./admin-doctor-list-operation.component.css']
})
export class AdminDoctorListOperationComponent implements OnInit {

  employee: AdminDoctor[];

  constructor(
    private _loginService: LoginpartService,
  private _route:Router
) { }

  ngOnInit(): void {

    this._loginService.checkUserValid()
      .subscribe(data => {
        console.log("the data from backend" + JSON.stringify(data));

        this.employee = data;

      });

  }

  updateDoctor() {

    this._route.navigate(['/updateLoginDetailDoctor']);

  }

  

  deleteDoctor(id: any) {
    this._loginService.deleteDoctorByIdRemote(id).subscribe(data => {
      console.log(data);

      this._loginService.checkUserValid()
        .subscribe(data => {
         this.employee = data;
        });



    }, error => console.log("error")
    )


  }


  goToAddDoctor() {

      this._route.navigate(['/addDoctor']);
  }













}
