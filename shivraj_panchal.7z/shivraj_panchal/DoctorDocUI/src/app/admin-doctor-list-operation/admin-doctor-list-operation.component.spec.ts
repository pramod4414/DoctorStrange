import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminDoctorListOperationComponent } from './admin-doctor-list-operation.component';

describe('AdminDoctorListOperationComponent', () => {
  let component: AdminDoctorListOperationComponent;
  let fixture: ComponentFixture<AdminDoctorListOperationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminDoctorListOperationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminDoctorListOperationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
