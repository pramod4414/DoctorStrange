import { Component, OnInit } from '@angular/core';
import { AdminDoctor } from '../admin-doctor';
import { Admincheck } from '../admincheck';
import { LoginpartService } from '../AllServices/loginpart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
  doctorDetailObj = new Admincheck
  constructor(private _service: LoginpartService,
    private _route: Router) { }

  loginDataFromRemote: any[] = [];

  ngOnInit(): void {
    this._service.checkAdminValid()
      .subscribe(data => {
        console.log("data from remote" + JSON.stringify(data));

        this.loginDataFromRemote = data;
      });
  }



  addDoctor(abc: any) {

      //console.log("function called checkCredientials" + this.doctorDetailObj.username + "*****pass" + this.doctorDetailObj.password);

      for (let a = 0; a < this.loginDataFromRemote.length; a++) {
      if (this.loginDataFromRemote[a].adminUsername == this.doctorDetailObj.username && this.loginDataFromRemote[a].adminPassword == this.doctorDetailObj.password) {
        console.log("i m in right condition");

        this._route.navigate(['/AdminDoctorOperation']);
      }

    }



  }
}
