import { Admincheck } from './admincheck';

describe('Admincheck', () => {
  it('should create an instance', () => {
    expect(new Admincheck()).toBeTruthy();
  });
});
