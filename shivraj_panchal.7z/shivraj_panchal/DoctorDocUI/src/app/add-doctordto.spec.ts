import { AddDoctordto } from './add-doctordto';

describe('AddDoctordto', () => {
  it('should create an instance', () => {
    expect(new AddDoctordto()).toBeTruthy();
  });
});
