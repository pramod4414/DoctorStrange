export class AdminDoctor {
   
    username:string;
    password:string;
}
