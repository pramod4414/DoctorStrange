/*package com.doctor.op.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.doctor.op.model.Login;
import com.doctor.op.repo.RepositoryDoctor;


@RestController
@RequestMapping("/api/v1")
public class HomeController {

	
	
	
	@Autowired
	private RepositoryDoctor repo;
	

	@RequestMapping("/employees")
	public List<Login> getDataOfLogin() {

		return repo.findAll();

	}
	
	
	
	@RequestMapping("/")
	public String home_Controller()  {

		System.out.println("pramod");
		
	List<Login> mno=	loginservice.getDataOfLogin();
		
	System.out.println(mno);	
	System.out.println(mno);	
		return "test";
	}

	
	
}
*/