package com.doctor.op.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.doctor.op.model.Admin;
import com.doctor.op.model.Employee;
import com.doctor.op.service.AdminCrudService;
import com.doctor.op.service.EmployeeCrudService;

@RestController
public class EmployeeRestController {

	@Autowired
	private EmployeeCrudService service;
	
	@Autowired
	private AdminCrudService adminService;
	


	
	@CrossOrigin(origins="http://localhost:4200")
	@GetMapping("/getAllLoginData")
	public List<Employee> fetchAllEmployee() {
		//objcreated
		List<Employee> allemp = new ArrayList<Employee>();
		allemp = service.fetchrecords();
	
		allemp.toString();
		return allemp;

	}
	
	
	@CrossOrigin(origins="http://localhost:4200")
	@GetMapping("/getAdminData")
	public List<Admin> fetchAllAdmin() {
		
		List<Admin> adminData = new ArrayList<Admin>();
		adminData = adminService.fetchrecords();
		adminData.toString();
		return adminData ;

	}
	
	
	@CrossOrigin(origins="http://localhost:4200")
	@DeleteMapping("/deleteEmployee/{id}")
	public void deleteEmployeeById(@PathVariable int id) {

		service.deletebyidmethod(id);

	}
	
	@CrossOrigin(origins="http://localhost:4200")
	@PostMapping("/addemployee")
	public Employee saveemp(@RequestBody Employee employee) {
		return service.saveEmployee(employee);

	}
	
	
	@CrossOrigin(origins="http://localhost:4200")
	@GetMapping("/searchEmployee/{id}")
	public Employee searchEmployeeById(@PathVariable int id) {

		return service.searchbyidmethod(id).get();

	}
	
	
	@PutMapping("/updateEmployee/{id}")
	public Employee updateStudent(@RequestBody Employee employee, @PathVariable int id) {
		Employee abc = null;
		boolean isemployeepresent = service.searchbyidmethod(id).isPresent();

		if (isemployeepresent == true) {
			try {
				employee.setId(id);

				abc = service.saveEmployee(employee);


			} catch (Exception e) {
				// TODO: handle exception
			}

		}

		return abc;
	}
	
	
	
/*	@CrossOrigin(origins="http://localhost:4200")
	@PostMapping("/addemployee")
	public Employee saveemp(@RequestBody Employee employee) {
		return service.saveEmployee(employee);

	}

	@CrossOrigin(origins="http://localhost:4200")
	@GetMapping("/searchEmployee/{id}")
	public Employee searchEmployeeById(@PathVariable int id) {

		return service.searchbyidmethod(id).get();

	}
	@CrossOrigin(origins="http://localhost:4200")
	@DeleteMapping("/deleteEmployee/{id}")
	public void deleteEmployeeById(@PathVariable int id) {

		service.deletebyidmethod(id);

	}

	@PutMapping("/updateEmployee/{id}")
	public Employee updateStudent(@RequestBody Employee employee, @PathVariable int id) {
		Employee abc = null;
		boolean isemployeepresent = service.searchbyidmethod(id).isPresent();

		if (isemployeepresent == true) {
			try {
				employee.setId(id);

				abc = service.saveEmployee(employee);


			} catch (Exception e) {
				// TODO: handle exception
			}

		}

		return abc;
	}*/

}