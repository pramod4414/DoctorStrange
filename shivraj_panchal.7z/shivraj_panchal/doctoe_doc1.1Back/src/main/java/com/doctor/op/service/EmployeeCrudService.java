package com.doctor.op.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doctor.op.model.Admin;
import com.doctor.op.model.Employee;
import com.doctor.op.repo.EmployeeCrudRepo;




@Service
public class EmployeeCrudService {
	
	@Autowired
	private EmployeeCrudRepo repo;

	public List<Employee> fetchrecords() {

		return repo.findAll();

	}
	

	
	 public Employee saveEmployee(Employee employee)
	 {
		 return repo.save(employee);
	 }
	
	 
	 public Optional<Employee> searchbyidmethod(int id)
	 {
		 return repo.findById(id);
	 }
	

	 
	 public void deletebyidmethod(int id)
	 {
		  repo.deleteById(id);
	 }
	 
}
