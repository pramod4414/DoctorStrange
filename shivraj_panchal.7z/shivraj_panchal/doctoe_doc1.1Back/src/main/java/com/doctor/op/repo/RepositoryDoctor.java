/*package com.doctor.op.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.doctor.op.model.Login;


@Repository
public interface RepositoryDoctor  extends JpaRepository<Login, Long> {
	
	
	

} */