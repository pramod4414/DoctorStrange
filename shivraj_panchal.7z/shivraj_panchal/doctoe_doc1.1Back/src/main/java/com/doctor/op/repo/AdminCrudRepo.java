package com.doctor.op.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.doctor.op.model.Admin;


@Repository
public interface AdminCrudRepo extends JpaRepository<Admin,Integer> {

}
