/*package com.doctor.op.model;


import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "Login_Details")
public class Login {

	private String username;
	private long id;
	private String password;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Login [username=" + username + ", id=" + id + ", password=" + password + "]";
	}

}
*/