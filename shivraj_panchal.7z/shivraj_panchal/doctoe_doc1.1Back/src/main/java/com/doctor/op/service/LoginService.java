/*package com.doctor.op.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doctor.op.model.Login;
import com.doctor.op.repo.RepositoryDoctor;


@Service
public class LoginService {

	@Autowired
	private RepositoryDoctor repo;
	

public List<Login> getDataOfLogin() {

		return repo.findAll();

	}
}*/