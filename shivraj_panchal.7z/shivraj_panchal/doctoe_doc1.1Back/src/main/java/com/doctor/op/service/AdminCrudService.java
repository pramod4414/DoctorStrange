package com.doctor.op.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doctor.op.model.Admin;
import com.doctor.op.repo.AdminCrudRepo;

@Service
public class AdminCrudService {
	
	@Autowired
	private AdminCrudRepo adminRepo;
	
	
	public List<Admin> fetchrecords() {

		return adminRepo.findAll();

	}

}
