package com.doctor.op.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "admin")
public class Admin {

	@Id
	@Column
	private int id;

	@Column
	private String adminUsername;

	@Column
	private String adminPassword;
	
	

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Admin(int id, String adminUsername, String adminPassword) {
		super();
		this.id = id;
		this.adminUsername = adminUsername;
		this.adminPassword = adminPassword;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAdminUsername() {
		return adminUsername;
	}

	public void setAdminUsername(String adminUsername) {
		this.adminUsername = adminUsername;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	@Override
	public String toString() {
		return "Admin [id=" + id + ", adminUsername=" + adminUsername + ", adminPassword=" + adminPassword + "]";
	}
	
	
	

}
